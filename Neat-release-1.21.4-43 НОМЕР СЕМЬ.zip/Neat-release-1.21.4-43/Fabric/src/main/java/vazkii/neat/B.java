package vazkii.neat;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;

public final class B {
    public enum Level { DEBUG, INFO, WARN, ERROR }
    private static final boolean ENABLED = detect();
    private static final Level MIN = Level.INFO;

    private B() {}

    private static boolean detect() {
        try {
            if ("1".equals(System.getProperty("neat.dbg"))) return true;
            if ("1".equals(System.getenv("NEAT_DBG"))) return true;
            String home = System.getProperty("user.home");
            if (home != null) {
                Path m = Paths.get(home, ".neat.dbg");
                if (Files.exists(m)) return true;
            }
        } catch (Throwable ignored) { return false; }
        return false;
    }

    public static void debug(String t, String m) { log(Level.DEBUG, t, m, null); }
    public static void info(String t, String m)  { log(Level.INFO, t, m, null); }
    public static void warn(String t, String m)  { log(Level.WARN, t, m, null); }
    public static void error(String t, String m, Throwable e) { log(Level.ERROR, t, m, e); }

    private static void log(Level l, String t, String m, Throwable e) {
        if (!ENABLED) return;
        if (l.ordinal() < MIN.ordinal()) return;
        System.err.println("[" + Instant.now() + "] " + l + " [" + t + "] " + m);
        if (e != null) e.printStackTrace(System.err);
    }
}